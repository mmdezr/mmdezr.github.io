int mi_strlen (char* str);
char* mi_strcpy (char* s1, char* s2);
char* mi_strdup (char* str);
char* mi_strcat (char* s1, char* s2);
int mi_strequals (char* s1, char* s2);
int testeador();

